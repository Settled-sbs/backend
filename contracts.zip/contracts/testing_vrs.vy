# @version ^0.4.3

# Domain Separator Typehash
EIP712_TYPEHASH: constant(bytes32) = keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)")
PERMIT_TYPEHASH: constant(bytes32) = keccak256("Execute(address owner,uint256 value,uint256 nonce,uint256 deadline)")

# State variables to prevent replays
nonces: public(HashMap[address, uint256])
DOMAIN_SEPARATOR: public(bytes32)

@deploy
def __init__():
    self.DOMAIN_SEPARATOR = keccak256(
        _abi_encode(
            EIP712_TYPEHASH,
            keccak256("MyApp"),
            keccak256("1"),
            chain.id,  # Prevents cross-chain replays
            self
        )
    )

@external
def execute_with_signature(
    owner: address, 
    _value: uint256, 
    deadline: uint256, 
    v: uint8, 
    r: bytes32, 
    s: bytes32
) -> bool:
    assert block.timestamp <= deadline, "Signature expired"

    # 1. Fetch current nonce for user
    current_nonce: uint256 = self.nonces[owner]

    # 2. Hash message payload including chain.id (via DOMAIN_SEPARATOR) and current_nonce
    struct_hash: bytes32 = keccak256(
        _abi_encode(
            PERMIT_TYPEHASH,
            owner,
            _value,
            current_nonce,
            deadline
        )
    )
    
    digest: bytes32 = keccak256(
        concat(
            b"\x19\x01",
            self.DOMAIN_SEPARATOR,
            struct_hash
        )
    )

    # 3. Recover signer
    signer: address = ecrecover(digest, v, r, s)
    assert signer != empty(address) and signer == owner, "Invalid signature"

    # 4. Increment nonce to invalidate the signature for future use
    self.nonces[owner] = current_nonce + 1

    return True